<p class = "copyright">&copy; 2024 Vegan Eats</p>
