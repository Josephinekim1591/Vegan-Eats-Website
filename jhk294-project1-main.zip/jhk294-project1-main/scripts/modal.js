$("#contactme").click(function () {
    $("#myModal").removeClass("hidden");
    $("#shadow").removeClass("hidden");
});

$("#close").click(function () {
    $("#myModal").addClass("hidden");
    $("#shadow").addClass("hidden");

});
