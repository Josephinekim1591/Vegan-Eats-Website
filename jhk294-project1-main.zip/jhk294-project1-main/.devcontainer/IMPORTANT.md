# Warning

The **.devcontainer** folder is used by Codespace to configure your repoistory.

**Do not place _any_ files in this folder!** We will not grade any files submitted for credit from this folder.

If you're unsure where to place files in your repository, please read the assignment's instructions or seek help with the assignment.
